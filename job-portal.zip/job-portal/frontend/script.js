const API = "http://localhost:5000/jobs";

async function fetchJobs() {
  try {
    const res = await fetch(API);
    const jobs = await res.json();
    renderJobs(jobs);
  } catch (e) {
    document.getElementById("jobs").innerHTML = "<p style='color:red'>Failed to load jobs. Is backend running?</p>";
    console.error(e);
  }
}

function renderJobs(jobs) {
  const wrap = document.getElementById("jobs");
  if (!Array.isArray(jobs) || jobs.length === 0) {
    wrap.innerHTML = "<div class='card'>No jobs yet. Be the first to post!</div>";
    return;
  }
  wrap.innerHTML = jobs.map(j => `
    <div class="job">
      <h3>${escapeHtml(j.title)}</h3>
      <div class="meta"><strong>${escapeHtml(j.company)}</strong> • ${escapeHtml(j.location || "")}</div>
      <p>${escapeHtml(j.description || "")}</p>
    </div>
  `).join("");
}

document.getElementById("jobForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const title = document.getElementById("title").value.trim();
  const company = document.getElementById("company").value.trim();
  const location = document.getElementById("location").value.trim();
  const description = document.getElementById("description").value.trim();
  const msg = document.getElementById("msg");
  msg.textContent = "Saving...";
  try {
    const res = await fetch(API, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ title, company, location, description })
    });
    if (!res.ok) throw new Error("Request failed");
    await fetchJobs();
    e.target.reset();
    msg.textContent = "Job added ✅";
    setTimeout(() => msg.textContent = "", 1500);
  } catch (err) {
    msg.textContent = "Error adding job";
    console.error(err);
  }
});

function escapeHtml(str){
  return String(str || "").replace(/[&<>"']/g, s => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  }[s]));
}

fetchJobs();
