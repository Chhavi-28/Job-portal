
# Job Portal (Frontend + Backend)

## Run Backend
1) Open Command Prompt (CMD) and run:
```
cd backend
npm install
npm start
```
Backend will run at: http://localhost:5000

## Run Frontend
Option A (quick):
- Open `frontend/index.html` by double-clicking it.

Option B (local server, recommended):
```
cd frontend
python -m http.server 3000
```
Open: http://localhost:3000

## API
- GET `/jobs` → list all jobs
- POST `/jobs` with JSON body:
```
{
  "title": "Software Engineer",
  "company": "Acme Corp",
  "location": "Bengaluru",
  "description": "Build services"
}
```
