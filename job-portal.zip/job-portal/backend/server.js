const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(bodyParser.json());

const db = new sqlite3.Database("./database.db", (err) => {
  if (err) console.error("SQLite connection error:", err.message);
  else console.log("SQLite connected ✅");
});

db.run(`CREATE TABLE IF NOT EXISTS jobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT,
  company TEXT,
  location TEXT,
  description TEXT
)`);

db.get("SELECT COUNT(*) AS count FROM jobs", (err, row) => {
  if (err) return console.error("Count error:", err.message);
  if (row.count === 0) {
    db.run(
      `INSERT INTO jobs (title, company, location, description) VALUES (?, ?, ?, ?)`,
      ["Software Engineer", "Acme Corp", "Bengaluru", "Build scalable web services."],
      (e) => e ? console.error("Seed insert error:", e.message) : console.log("Seed job inserted ✅")
    );
  }
});

app.get("/", (req, res) => res.send("Job Portal Backend Running 🚀"));

app.get("/jobs", (req, res) => {
  db.all("SELECT * FROM jobs ORDER BY id DESC", [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post("/jobs", (req, res) => {
  const { title, company, location, description } = req.body || {};
  if (!title || !company || !location) {
    return res.status(400).json({ error: "title, company, location are required" });
  }
  db.run(
    `INSERT INTO jobs (title, company, location, description) VALUES (?, ?, ?, ?)`,
    [title, company, location, description || ""],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID, title, company, location, description: description || "" });
    }
  );
});

app.listen(PORT, () => console.log(`Backend running on http://localhost:${PORT}`));
